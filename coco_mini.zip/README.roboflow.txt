
COCO 128 - v2 640x640
==============================

This dataset was exported via roboflow.ai on September 29, 2021 at 3:40 AM GMT

It includes 378 images.
Common-objects are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


